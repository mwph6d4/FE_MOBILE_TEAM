//package com.example.accesorismvvm.domain.usecase
//
//import com.example.accesorismvvm.domain.repository.ProductRepository
//import javax.inject.Inject
//
//class importProductFromCsvUseCase @Inject constructor(
//    private val productRepository: ProductRepository
//) {
//    suspend operator fun invoke(){
//        productRepository.importProductFromCsv()
//    }
//}