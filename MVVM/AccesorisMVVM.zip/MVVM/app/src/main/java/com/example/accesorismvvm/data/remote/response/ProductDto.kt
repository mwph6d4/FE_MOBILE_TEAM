package com.example.accesorismvvm.data.remote.response

data class ProductDto(
    val id: Int,
    val name: String,
    val description: String?,
    val price: Double,
    val images: List<ImageDto>
)

data class ImageDto(
    val id: Int,
    val image_url: String,
    val is_main: Boolean
)

