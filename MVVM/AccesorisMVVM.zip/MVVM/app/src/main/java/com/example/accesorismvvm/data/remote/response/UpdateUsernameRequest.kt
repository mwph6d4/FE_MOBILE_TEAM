package com.example.accesorismvvm.data.remote.response

data class UpdateUsernameRequest(
    val username: String
)
