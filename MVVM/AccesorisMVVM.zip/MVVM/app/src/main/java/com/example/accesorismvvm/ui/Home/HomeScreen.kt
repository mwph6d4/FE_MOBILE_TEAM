package com.example.accesorismvvm.ui.Home

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.accesorismvvm.R
import com.example.accesorismvvm.domain.model.Product
import com.example.accesorismvvm.ui.product.ProductViewModel
import androidx.compose.ui.draw.clip

import java.nio.file.WatchEvent
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: ProductViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val products by viewModel.produk.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

//    val categories = remember {
//        listOf("Elektronik", "Fashion", "Rumah Tangga", "Buku", "Olahraga", "Kecantikan", "Makanan", "Mainan")
//    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                // ✅ Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.logofix2),
                        contentDescription = "Banner Promo",
                        contentScale = ContentScale.Crop, // atau FillWidth jika ingin tidak terpotong
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp) // Padding kiri, kanan, atas, bawah
                            .clip(RoundedCornerShape(16.dp))
                    )
                }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F0F0)),
                    onClick = { navController.navigate("search_screen") }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize() // Pastikan isi Row memenuhi tinggi Card
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically // Tengah secara vertikal
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.outline_search_24),
                            contentDescription = "Search",
                            tint = Color(0xFFD3D3D3)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Cari produk di AccessoriesBox",
                            color = Color(0xFFD3D3D3),
                            fontSize = 16.sp
                        )
                    }
                }


//                // ✅ Categories
//                Column {
//                    Text(
//                        "Kategori",
//                        fontWeight = FontWeight.SemiBold,
//                        fontSize = 16.sp,
//                        modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
//                    )
//                    Row(
//                        modifier = Modifier
//                            .fillMaxWidth()
//                            .horizontalScroll(rememberScrollState())
//                            .padding(horizontal = 8.dp),
//                        horizontalArrangement = Arrangement.spacedBy(12.dp)
//                    ) {
////                        categories.forEach { category ->
////                            Column(
////                                horizontalAlignment = Alignment.CenterHorizontally,
////                                modifier = Modifier
////                                    .width(72.dp)
////                                    .clickable {
////                                        Toast.makeText(context, "Kategori: $category", Toast.LENGTH_SHORT).show()
////                                    }
////                            ) {
////                                Box(
////                                    modifier = Modifier
////                                        .size(48.dp)
////                                        .background(Color.LightGray, CircleShape)
////                                )
////                                Spacer(modifier = Modifier.height(4.dp))
////                                Text(
////                                    text = category,
////                                    fontSize = 10.sp,
////                                    textAlign = TextAlign.Center,
////                                    maxLines = 1,
////                                    overflow = TextOverflow.Ellipsis
////                                )
////                            }
////                        }
//                    }
//                }

                Spacer(modifier = Modifier.height(12.dp))

//                // ✅ Rekomendasi Title
//                Text(
//                    text = "Rekomendasi",
//                    fontWeight = FontWeight.Bold,
//                    fontSize = 16.sp,
//                    modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
//                )
            }

            // ✅ Product Grid (2 columns)
            items(products.chunked(2)) { rowItems ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { product ->
                        ProductCardShopee(
                            product = product,
                            navController = navController,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowItems.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

fun Double.toRupiah(): String {
    val format = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
    return format.format(this)
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductCardShopee(
    product: Product,
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(250.dp),
        onClick = { navController.navigate("product_detail/${product.id}") }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Image(
                painter = rememberAsyncImagePainter(product.imageUrl),
                contentDescription = product.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                contentScale = ContentScale.Crop
            )
            Column(
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = product.price.toRupiah(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Rating",
                        tint = Color(0xFFFFC107),
                        modifier = Modifier.size(16.dp)
                    )
//                    Text(
//                        text = "${product.rating} (${product.reviewCount})",
//                        style = MaterialTheme.typography.bodySmall,
//                        modifier = Modifier.padding(start = 4.dp)
//                    )
                }
            }
        }
    }
}
