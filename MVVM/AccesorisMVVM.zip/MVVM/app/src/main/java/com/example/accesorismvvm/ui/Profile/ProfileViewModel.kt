package com.example.accesorismvvm.ui.Profile

import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.accesorismvvm.data.local.entityDAO.UserEntity
import com.example.accesorismvvm.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.State
import com.example.accesorismvvm.data.Session.SessionManager
import com.example.accesorismvvm.domain.repository.AuthRepository


@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val userRepository: UserRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _user = mutableStateOf<UserEntity?>(null)
    val user: State<UserEntity?> = _user

    private val _logoutEvent = mutableStateOf(false)
    val logoutEvent: State<Boolean> = _logoutEvent

    init {
        viewModelScope.launch {
            val userId = sessionManager.getUserId()
            val token = sessionManager.getToken()

            try {
                if (!token.isNullOrEmpty()) {
                    authRepository.syncUserProfile(token)
                }
            } catch (e: Exception) {
                Log.e("ProfileViewModel", "Gagal sync ke server: ${e.message}")
            }

            if (userId != -1) {
                val userData = userRepository.getUserById(userId)
                _user.value = userData
            }
        }
    }

    fun logout() {
        sessionManager.clearSession()
        _logoutEvent.value = true
    }

    fun clearLogoutEvent() {
        _logoutEvent.value = false
    }
}
