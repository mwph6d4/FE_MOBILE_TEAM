package com.example.accesorismvvm.data.remote

import androidx.room.Query
import com.example.accesorismvvm.data.local.entityDAO.ProductEntity
import com.example.accesorismvvm.data.remote.request.LoginRequest
import com.example.accesorismvvm.data.remote.request.RegisterRequest
import com.example.accesorismvvm.data.remote.response.AuthResponse
import com.example.accesorismvvm.data.remote.response.ProductDto
import com.example.accesorismvvm.data.remote.response.ProductResponse
import com.example.accesorismvvm.data.remote.response.UserDto

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.Response
import retrofit2.http.PUT
import retrofit2.http.Path


interface ApiService {

    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): AuthResponse

    @POST("auth/register")
    suspend fun register(@Body request: RegisterRequest): AuthResponse

    @GET("users/profile")
    suspend fun getUserProfile(
        @Header("Authorization") token: String
    ): UserDto

    @GET("products/")
    suspend fun getProducts(): Response<ProductResponse>

    @GET("products/{id}") // Ganti sesuai endpoint API Anda untuk detail produk
    suspend fun getProductDetail(@Path("id") productId: Int): ProductEntity // Sesuaikan dengan respons API Anda

    @PUT("profile/username")
    suspend fun updateUsername(
        @Header("Authorization") token: String
    ): UserDto


}
//    @GET("products/{id}")
//    suspend fun getProductDetail(
//        @Path("id") id: Int,
//        @Header("Authorization") token: String
//    ): ProductDetailDto




//    @GET("products/")
//    suspend fun getAllProducts(
//        @retrofit2.http.Query("page") page: Int = 1,
//        @retrofit2.http.Query("per_page") perPage: Int = 20,
//        @retrofit2.http.Query("sort_by") sortBy: String = "created_at",
//        @retrofit2.http.Query("sort_order") sortOrder: String = "desc"
//    ): ProductResponse
