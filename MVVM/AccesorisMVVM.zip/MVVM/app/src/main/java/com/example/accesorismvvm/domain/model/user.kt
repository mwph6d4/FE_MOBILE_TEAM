package com.example.accesorismvvm.domain.model

data class user(
    val id: Int = 0,
    val username: String,
    val password: String,
    val email: String

    )