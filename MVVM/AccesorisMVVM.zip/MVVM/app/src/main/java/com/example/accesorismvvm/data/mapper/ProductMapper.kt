package com.example.accesorismvvm.data.mapper

import com.example.accesorismvvm.data.local.entityDAO.ProductEntity
import com.example.accesorismvvm.data.remote.response.ProductDto
import com.example.accesorismvvm.domain.model.Product

fun ProductDto.toEntity(): ProductEntity {
    return ProductEntity(
        id = id,
        name = name,
        description = description ?: "",
        price = price,
        imageUrl = images.firstOrNull { it.is_main }?.image_url ?: ""
    )
}

fun ProductEntity.toDomain(): Product {
    return Product(
        id = this.id,
        name = this.name,
        description = this.description,
        price = this.price,
        imageUrl = this.imageUrl
        // tambahkan properti lain jika ada
    )
}
//fun ProductDetailDto.toDomain(): ProductDetail = ProductDetail(
//    id, name, description, price, imageUrl, brand?.name ?: "Unknown", stock ?: 0
//)
//
//data class ProductDetail(
//    val id: Int,
//    val name: String,
//    val description: String?,
//    val price: Double,
//    val imageUrl: String,
//    val brandName: String,
//    val stock: Int
//)
