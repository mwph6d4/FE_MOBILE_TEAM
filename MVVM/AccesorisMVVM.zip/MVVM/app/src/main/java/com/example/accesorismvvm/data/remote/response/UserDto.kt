package com.example.accesorismvvm.data.remote.response

import com.example.accesorismvvm.data.local.entityDAO.UserEntity
import com.example.accesorismvvm.domain.model.user

data class UserDto(
    val id: Int,
    val name: String,
    val email: String,
    val password: String
)

fun UserDto.toEntity(): UserEntity {
    return UserEntity(
        id = this.id,
        username = this.name,
        email = this.email,
        password = this.password
    )
}

fun UserEntity.toDomain(): user {
    return user(
        id = this.id,
        username = this.username,
        password = this.password,
        email = this.email
    )
}