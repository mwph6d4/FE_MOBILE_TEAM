package com.example.accesorismvvm.domain.repository


import com.example.accesorismvvm.data.local.entityDAO.ProductEntity
import com.example.accesorismvvm.domain.model.Product
import kotlinx.coroutines.flow.Flow

interface ProductRepository {
    fun getAllProducts(): Flow<List<Product>>
    suspend fun fetchProductsFromServer()
    suspend fun getProductDetail(productId: Int): Product?
    suspend fun searchProducts(query: String): List<Product>
// suspend fun getProductDetail(productId: Int): Product

}

