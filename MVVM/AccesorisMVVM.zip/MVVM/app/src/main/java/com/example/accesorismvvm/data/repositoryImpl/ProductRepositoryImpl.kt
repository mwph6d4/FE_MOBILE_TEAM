package com.example.accesorismvvm.data.repositoryImpl

import android.content.Context
import android.util.Log
import com.example.accesorismvvm.data.local.database.AppDatabase
import com.example.accesorismvvm.data.local.entityDAO.ProductDao
import com.example.accesorismvvm.data.local.entityDAO.ProductEntity
import com.example.accesorismvvm.data.remote.ApiService
import com.example.accesorismvvm.domain.model.Product
import com.example.accesorismvvm.domain.repository.ProductRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import com.example.accesorismvvm.data.mapper.toDomain
import com.example.accesorismvvm.data.mapper.toEntity


class ProductRepositoryImpl @Inject constructor(
    private val api: ApiService,
    private val dao: ProductDao
) : ProductRepository {

    override fun getAllProducts(): Flow<List<Product>> {
        return dao.getAllProducts().map { it.map { entity -> entity.toDomain() } }
    }

    override suspend fun fetchProductsFromServer() {
        val response = api.getProducts()
        if (response.isSuccessful) {
            response.body()?.let { productResponse ->
                val entities = productResponse.products.map { it.toEntity() }
//                dao.clearAll()
                dao.insertAll(entities)
            }
        } else {
            throw Exception("Server Error: ${response.code()}")
        }
    }

    override suspend fun getProductDetail(productId: Int): Product? {
        return try {
            // Coba ambil dari database lokal (Room) terlebih dahulu
            val productEntity = dao.getProductById(productId)
            if (productEntity != null) {
                return productEntity.toDomain()
            }

            // Jika tidak ada di Room, ambil dari server
            val apiResponse = api.getProductDetail(productId)
            // Lakukan pemetaan dari ProductEntity (yang didapat dari API) ke Product domain model
            val productDetail = apiResponse.toDomain() // Asumsi ada fungsi ekstensi toDomain()

            // Opsional: Simpan ke Room setelah diambil dari server
            dao.insert(apiResponse)

            productDetail
        } catch (e: Exception) {
            // Handle error, misalnya log exception atau tampilkan pesan ke user
            e.printStackTrace()
            null
        }
    }
}



