package com.example.accesorismvvm.domain.repository

import com.example.accesorismvvm.data.local.entityDAO.UserDao
import com.example.accesorismvvm.data.local.entityDAO.UserEntity
import com.example.accesorismvvm.data.remote.response.UpdateUsernameRequest
import com.example.accesorismvvm.domain.model.user
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class UserRepository @Inject constructor(private val userDao: UserDao) {
    suspend fun register(user: UserEntity) = userDao.insert(user)
    suspend fun getUserByEmail(email: String) = userDao.getUserByEmail(email)
    suspend fun getUserById(UserId: Int) = userDao.getUserById(UserId)
    suspend fun fetchUserProfile(token: String): user?
    fun getUserProfileStream(): Flow<user?> // Untuk mendapatkan pembaruan profil secara real-time dari Room
    suspend fun updateUsername(token: String, newUsername: String): user?

}
