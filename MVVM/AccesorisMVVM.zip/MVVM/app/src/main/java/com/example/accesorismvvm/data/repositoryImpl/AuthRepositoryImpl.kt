package com.example.accesorismvvm.data.repositoryImpl

import com.example.accesorismvvm.data.local.entityDAO.UserDao
import com.example.accesorismvvm.data.local.entityDAO.UserEntity
import com.example.accesorismvvm.data.remote.ApiService
import com.example.accesorismvvm.data.remote.RemoteDataSource
import com.example.accesorismvvm.data.remote.request.LoginRequest
import com.example.accesorismvvm.data.remote.request.RegisterRequest
import com.example.accesorismvvm.data.remote.response.AuthResponse
import com.example.accesorismvvm.domain.repository.AuthRepository
import java.util.prefs.Preferences
import javax.inject.Inject

class AuthRepositoryImpl @Inject constructor(
    private val remoteDataSource: RemoteDataSource,
    private val userDao: UserDao
) : AuthRepository {

    override suspend fun register(name: String, email: String, password: String): AuthResponse {
        val response = remoteDataSource.register(RegisterRequest(name, email, password))

        response.user?.let {
            val userEntity = UserEntity(
                id = it.id, // ← tambahkan ini
                username = it.name,
                email = it.email,
                password = password
            )
            userDao.insert(userEntity)
        }
        return response
    }

    override suspend fun login(email: String, password: String): AuthResponse {
        val response = remoteDataSource.login(LoginRequest(email, password))

        response.user?.let {
            val userEntity = UserEntity(
                id = it.id, // ← tambahkan ini juga
                username = it.name,
                email = it.email,
                password = password
            )
            userDao.insert(userEntity)
        }
        return response
    }

    override suspend fun syncUserProfile(token: String) {
        val userDto = remoteDataSource.getUserProfile(token)

        val userEntity = UserEntity(
            id = userDto.id,
            username = userDto.name,
            email = userDto.email,
            password = "" // kosongkan karena tidak didapat dari server
        )

        userDao.insert(userEntity)
    }



}


