package com.example.accesorismvvm.data.remote.response

//data class ProductDetailDto(
//    val id: Int,
//    val name: String,
//    val description: String?,
//    val price: Double,
//    val imageUrl: String,
//    val brand: BrandDto?,
//    val stock: Int?
//)
//
//data class BrandDto(
//    val id: Int,
//    val name: String
//)
