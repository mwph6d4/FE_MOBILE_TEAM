package com.example.accesorismvvm.data.repositoryImpl

import com.example.accesorismvvm.data.local.entityDAO.UserDao
import com.example.accesorismvvm.data.remote.ApiService
import com.example.accesorismvvm.domain.model.user
import com.example.accesorismvvm.domain.repository.UserRepository
import javax.inject.Inject

class UserRepositoryImpl @Inject constructor(
    private val api: ApiService,
    private val userDao: UserDao // Jika Anda menyimpan profil di Room
) : UserRepository {

    // Mengambil profil dari server dan menyimpannya ke Room
    override suspend fun fetchUserProfile(token: String): user? {
        return try {
            val userDto = api.getUserProfile(token)
            val userEntity = userDto.toEntity()
            userDao.insertUser(userEntity) // Simpan ke Room
            userEntity.toDomain()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Mendapatkan profil dari Room sebagai Flow (untuk pembaruan UI real-time)
    override fun getUserProfileStream(): Flow<user?> {
        return userDao.getUserProfile().map { it?.toDomain() }
    }

    // Memperbarui username di server dan juga di Room
    override suspend fun updateUsername(token: String, newUsername: String): User? {
        return try {
            val request = UpdateProfileRequest(username = newUsername)
            val updatedUserDto = api.updateProfile(token, request)
            val updatedUserEntity = updatedUserDto.toEntity()
            userDao.insertUser(updatedUserEntity) // Update di Room juga
            updatedUserEntity.toDomain()
        } catch (e: Exception) {
            e.printStackTrace()
            throw e // Lemparkan exception agar ViewModel bisa menangani error
        }
    }
}